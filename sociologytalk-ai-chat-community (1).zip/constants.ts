
export const CHAT_ROOMS: string[] = [
  'Ask a Sociologist',
  'Study Advice (Psychology)',
  'Debate Corner',
  'Research Discussion',
];
